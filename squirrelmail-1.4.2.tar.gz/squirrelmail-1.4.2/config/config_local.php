<?php
/* Local config overrides.
   You can override the config.php settings here.  Don't do it unless you know what you're doing.
   Use standard PHP syntax, see config.php for examples. */
