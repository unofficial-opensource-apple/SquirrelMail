<?php

   /**
    **  index.php -- Displays the main frameset
    **
    **  Copyright (c) 1999-2003 The SquirrelMail development team
    **  Licensed under the GNU GPL. For full terms see the file COPYING.
    **
    **  Redirects to the login page.
    **
    **  $Id: index.php,v 1.5 2002/12/31 12:49:39 kink Exp $
    **/

   header("Location:../../../src/login.php\n\n");
   exit();

?>
